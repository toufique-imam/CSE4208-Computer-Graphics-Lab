#include "BazierCurve.h"

BazierCurve::BazierCurve()
{
    //ctor
}
